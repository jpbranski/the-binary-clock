'use client';

import Layout from '@/components/Layout';
import { useState } from 'react';

export default function Learn() {
  const [decimal, setDecimal] = useState<number | ''>('');
  const [copied, setCopied] = useState(false);

  // Format binary string with spacing every 4 bits (right-aligned grouping)
  const formatBinary = (num: number): string => {
    const raw = num.toString(2);
    const padded = raw.padStart(Math.ceil(raw.length / 4) * 4, '0');
    return padded.replace(/(.{4})(?=.)/g, '$1 ');
  };

  const binary =
    decimal === '' || isNaN(Number(decimal)) ? '' : formatBinary(Number(decimal));

  const tableData = Array.from({ length: 61 }, (_, i) => ({
    decimal: i,
    binary: i.toString(2).padStart(6, '0').replace(/(.{4})(?=.)/g, '$1 '),
  }));

  const handleCopy = () => {
    if (binary) {
      navigator.clipboard.writeText(binary);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  const sidebar = (
    <div className="text-[#c6a44c] uppercase tracking-wide font-medium text-sm px-4">
      Learn Binary
    </div>
  );

  return (
    <Layout sidebar={sidebar}>
      <div className="max-w-5xl mx-auto px-6 py-16 text-center text-gray-200">
        {/* Title */}
        <h1 className="text-4xl md:text-5xl font-light text-[#c6a44c] mb-8 tracking-wide">
          Learn Binary
        </h1>

        {/* Description */}
        <p className="text-lg md:text-xl text-gray-400 mb-10 leading-relaxed max-w-2xl mx-auto">
          Binary is the foundation of all digital logic. It uses only two
          symbols—<span className="text-[#c6a44c] font-semibold">0</span> and{' '}
          <span className="text-[#c6a44c] font-semibold">1</span>—each
          representing an on or off state. Every number, letter, and signal
          inside a computer ultimately reduces to these two digits.
        </p>

        {/* Visual breakdown */}
        <div className="bg-[#c6a44c]/10 border border-[#c6a44c]/30 rounded-lg py-6 px-8 mb-12 max-w-xl mx-auto text-left">
          <h2 className="text-[#c6a44c] text-2xl font-light mb-3 text-center">
            Example: How 13 Becomes Binary
          </h2>
          <pre className="font-mono text-lg text-[#c6a44c] leading-relaxed text-center">
            32&nbsp;16&nbsp;&nbsp;8&nbsp;&nbsp;4&nbsp;&nbsp;2&nbsp;&nbsp;1
            <br />
            0&nbsp;&nbsp;0&nbsp;&nbsp;1&nbsp;&nbsp;1&nbsp;&nbsp;0&nbsp;&nbsp;1
          </pre>
          <p className="text-center text-gray-400 mt-3">
            13 = <span className="text-[#c6a44c]">8 + 4 + 1</span>
          </p>
        </div>

        {/* Interactive converter */}
        <div className="bg-[#c6a44c]/10 border border-[#c6a44c]/30 rounded-lg py-8 px-6 mb-16 max-w-xl mx-auto">
          <h2 className="text-2xl font-light text-[#c6a44c] mb-4">
            Try it Yourself
          </h2>
          <p className="text-gray-400 mb-4">
            Type a decimal number to see its binary form:
          </p>
          <input
            type="number"
            value={decimal}
            onChange={(e) =>
              setDecimal(e.target.value === '' ? '' : Number(e.target.value))
            }
            className="w-40 mx-auto text-center bg-transparent border border-[#c6a44c]/50 rounded-md py-2 text-[#c6a44c] text-lg font-mono focus:outline-none focus:ring-2 focus:ring-[#c6a44c]/50"
            placeholder="e.g. 42"
          />
          {binary && (
            <div className="mt-6 flex flex-col items-center gap-2">
              <p className="text-gray-400">Binary:</p>
              <p className="text-2xl font-mono text-[#c6a44c] tracking-wider">
                {binary}
              </p>
              <button
                onClick={handleCopy}
                className="mt-2 px-4 py-1 text-sm border border-[#c6a44c]/50 text-[#c6a44c] rounded-md hover:bg-[#c6a44c]/10 transition"
              >
                {copied ? 'Copied!' : 'Copy'}
              </button>
            </div>
          )}
        </div>

        {/* Conversion Table */}
        <h2 className="text-2xl font-light text-[#c6a44c] mb-4">
          Decimal → Binary (0–60)
        </h2>
        <div className="overflow-x-auto max-w-xl mx-auto">
          <table className="w-full border-collapse text-[#c6a44c] font-mono text-sm">
            <thead className="bg-[#c6a44c]/10 border border-[#c6a44c]/30">
              <tr>
                <th className="border border-[#c6a44c]/30 py-2">Decimal</th>
                <th className="border border-[#c6a44c]/30 py-2">Binary</th>
              </tr>
            </thead>
            <tbody>
              {tableData.map(({ decimal, binary }) => (
                <tr
                  key={decimal}
                  className="odd:bg-transparent even:bg-[#c6a44c]/5"
                >
                  <td className="border border-[#c6a44c]/30 py-1">{decimal}</td>
                  <td className="border border-[#c6a44c]/30 py-1">{binary}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Outro */}
        <p className="mt-16 text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Behind every glowing pixel and ticking clock, there’s binary logic at
          work—counting, calculating, and synchronizing the world bit by bit.
        </p>
        <p className="mt-3 text-[#c6a44c] italic">
          Understand binary, and you understand time itself.
        </p>
      </div>
    </Layout>
  );
}
